﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Vilagbajnoksag
{
    public int Ev { get; set; }
    public string Rendezo { get; set; }
    public string Bajnok { get; set; }
}

namespace focivb2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LABDARUGO-VILÁGBAJNOKSÁG");
            Console.WriteLine("========================");
            Console.WriteLine("Adatok feldolgozása:1930-2022");


            List<Vilagbajnoksag> vbLista =
                new List<Vilagbajnoksag>();

            string[] sorok = File.ReadAllLines("focivb.txt");

            foreach (string sor in sorok)
            {
                string[] adatok = sor.Split(';');

                Vilagbajnoksag vb = new Vilagbajnoksag();

                vb.Ev = int.Parse(adatok[0]);
                vb.Rendezo = adatok[1];
                vb.Bajnok = adatok[2];

                vbLista.Add(vb);
            }

            Console.WriteLine("Az adatok beolvasása sikeres!");



            Console.WriteLine();
            Console.WriteLine("4. feladat");

            Console.WriteLine(
                "A világbajnokságok száma: "
                + vbLista.Count + " db");

            Console.ReadKey();
        }
    }
}