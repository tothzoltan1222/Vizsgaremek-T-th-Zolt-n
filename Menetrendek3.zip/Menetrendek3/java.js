document.getElementById("szamitas").addEventListener("click", function() {
    // Értékek kiolvasása és számmá alakítása a Number() függvénnyel[cite: 2]
    let indulas = Number(document.getElementById("indulas").value);[cite: 2]
    let erkezes = Number(document.getElementById("erkezes").value);[cite: 2]

    let eredmenyHely = document.getElementById("eredmeny");

    // Ha az indulás és az érkezés ugyanaz, figyelmeztetést írunk ki
    if (indulas === erkezes) {
        eredmenyHely.innerHTML = "Figyelem: Az indulási és érkezési állomás nem lehet azonos!";
        return;
    }

    // Menetidő kiszámítása[cite: 2]
    let menetido = Math.abs(erkezes - indulas);[cite: 2]

    // Eredmény megjelenítése
    eredmenyHely.innerHTML = "A vonat menetideje: " + menetido + " perc";
});