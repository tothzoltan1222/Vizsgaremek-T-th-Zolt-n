
<?php
$eredmeny = "";

if (isset($_GET["orszag"])) {
    $orszag = trim($_GET["orszag"]);

    try {
        $pdo = new PDO(
            "mysql:host=localhost;dbname=foldrajz;charset=utf8mb4",
            "root",
            ""
        );

        $sql = "SELECT orszag, fovaros FROM orszagok WHERE orszag = ?";
        $lekerdezes = $pdo->prepare($sql);
        $lekerdezes->execute([$orszag]);

        $talalat = $lekerdezes->fetch(PDO::FETCH_ASSOC);

        if ($talalat) {
            $eredmeny =
                htmlspecialchars($talalat["orszag"]) .
                " fővárosa: " .
                htmlspecialchars($talalat["fovaros"]);
        } else {
            $eredmeny = "A keresett ország nem található!";
        }

    } catch (PDOException $e) {
        $eredmeny = "Adatbázis-kapcsolati hiba!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Országok és fővárosok</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="doboz">

        <h1>Országok és fővárosok</h1>

        <p>Írd be egy ország nevét!</p>

        <form method="get">
            <input
                type="text"
                name="orszag"
                placeholder="Ország neve"
                required
            >

            <button type="submit">Keresés</button>
        </form>

        <?php if ($eredmeny != "") { ?>
            <div class="eredmeny">
                <?php echo $eredmeny; ?>
            </div>
        <?php } ?>

    </div>

</body>
</html>
