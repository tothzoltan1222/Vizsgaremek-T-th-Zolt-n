﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Vilagbajnoksag
{
    public int Ev { get; set; }
    public string Rendezo { get; set; }
    public string Bajnok { get; set; }
}

namespace focivb2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LABDARUGO-VILÁGBAJNOKSÁG");
            Console.WriteLine("========================");
            Console.WriteLine("Adatok feldolgozása:1930-2022");

            List<Vilagbajnoksag> vbLista =
                new List<Vilagbajnoksag>();

            string[] sorok = File.ReadAllLines("focivb.txt");

            foreach (string sor in sorok)
            {
                string[] adatok = sor.Split(';');

                Vilagbajnoksag vb = new Vilagbajnoksag();

                vb.Ev = int.Parse(adatok[0]);
                vb.Rendezo = adatok[1];
                vb.Bajnok = adatok[2];

                vbLista.Add(vb);
            }

            Console.WriteLine("Az adatok beolvasása sikeres!");

            Console.WriteLine();
            Console.WriteLine("4. feladat");

            Console.WriteLine(
                "A világbajnokságok száma: "
                + vbLista.Count + " db");


 
            Console.WriteLine();
            Console.WriteLine("5. feladat");

            Vilagbajnoksag elso = vbLista.OrderBy(x => x.Ev).First();
            Vilagbajnoksag utolso = vbLista.OrderBy(x => x.Ev).Last();

            Console.WriteLine("Az első világbajnokság:");
            Console.WriteLine("Év: " + elso.Ev);
            Console.WriteLine("Rendező: " + elso.Rendezo);
            Console.WriteLine("Bajnok: " + elso.Bajnok);

            Console.WriteLine();

            Console.WriteLine("Az utolsó világbajnokság:");
            Console.WriteLine("Év: " + utolso.Ev);
            Console.WriteLine("Rendező: " + utolso.Rendezo);
            Console.WriteLine("Bajnok: " + utolso.Bajnok);


    
            Console.WriteLine();
            Console.WriteLine("6. feladat");

            Console.Write("Adj meg egy évszámot: ");
            int ev = int.Parse(Console.ReadLine());

            Vilagbajnoksag keresett = vbLista
                .FirstOrDefault(x => x.Ev == ev);

            if (keresett != null)
            {
                Console.WriteLine("Rendező ország: " + keresett.Rendezo);
                Console.WriteLine("Világbajnok: " + keresett.Bajnok);
            }
            else
            {
                Console.WriteLine("Ebben az évben nem rendeztek világbajnokságot!");
            }


            Console.WriteLine();
            Console.WriteLine("7. feladat");

            Console.Write("Adj meg egy országnevet: ");
            string orszag = Console.ReadLine();

            int db = vbLista.Count(x =>
                x.Bajnok.ToLower() == orszag.ToLower());

            Console.WriteLine(orszag + " világbajnoki címeinek száma: " + db);


    
            Console.WriteLine();
            Console.WriteLine("8. feladat");

            var rendezettLista = vbLista
                .OrderByDescending(x => x.Ev);

            Console.WriteLine("Év       Rendező ország       Világbajnok");
            Console.WriteLine("-----------------------------------------");

            foreach (Vilagbajnoksag vb in rendezettLista)
            {
                Console.WriteLine(
                    vb.Ev + "     " +
                    vb.Rendezo + "             " +
                    vb.Bajnok);
            }


            Console.WriteLine();
            Console.WriteLine("9. feladat");

            Console.WriteLine("Hazai győzelmek:");

            foreach (Vilagbajnoksag vb in vbLista)
            {
                if (vb.Rendezo == vb.Bajnok)
                {
                    Console.WriteLine(
                        vb.Ev + " - " +
                        vb.Rendezo);
                }
            }

            Console.ReadKey();
        }
    }
}
